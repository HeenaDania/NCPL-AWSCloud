<section class="page_topline ls table_section section_padding_top_5 section_padding_bottom_5" id="topNav">
	<div class="container">
		<div class="row">
			<div class="col-sm-6 text-center text-sm-left">
				<p>
					<i class="fa fa-envelope leftpadding_5" aria-hidden="true"></i>
						doorohelp@gmail.com
					<i class="fa fa-phone leftpadding_5" aria-hidden="true"></i> 
						780-667-9023
				</p>
			</div>
			<div class="col-sm-6 text-center text-sm-right">
				<p class="greylinks small-icons">
					<span class="rightpadding_10">Follow us:</span>
						<a class="social-icon soc-facebook" target="_blank" href="https://en-gb.facebook.com/login/" title="Facebook"></a>
						<a class="social-icon soc-twitter" target="_blank" href="https://twitter.com/login?lang=en" title="Twitter"></a>
						<a class="social-icon soc-linkedin" target="_blank" href="https://www.linkedin.com/uas/login" title="LinkedIn"></a>
						<a class="social-icon soc-google" target="_blank" href="https://accounts.google.com/signin/v2/identifier?hl=EN&flowName=GlifWebSignIn&flowEntry=ServiceLogin" title="Google"></a>
				</p>
			</div>
		</div>
	</div>
</section>
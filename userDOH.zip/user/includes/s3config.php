<?php
return [
    's3' => [
        'key'    => getenv('AWS_ACCESS_KEY'),
        'secret' => getenv('AWS_SECRET_KEY'),
        'bucket' => 'doorohelp',
        'region' => 'us-east-1',
        'version' => 'latest'
    ]
];
?>
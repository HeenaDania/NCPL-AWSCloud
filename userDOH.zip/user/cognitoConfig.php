<?php
$cognito_domain = "https://us-east-1medkdgu5o.auth.us-east-1.amazoncognito.com";
$client_id = "4jp4024cugrvnftbfrt3tntl1r";
$redirect_uri = "https://alb-doorohelpappuser-1983017167.us-east-1.elb.amazonaws.com/callback.php";
$client_secret = ""; // If you don't use one, leave blank
?>
